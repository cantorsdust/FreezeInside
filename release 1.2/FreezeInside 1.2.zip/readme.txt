Freezes the game using the SMAPI Trainer Mod command "world_freezetime 1" when inside.  Unfreezes when outside.

Place dll in %appdata%\Stardew Valley\Mods.  REQUIRES BOTH SMAPI AND TrainerMod.dll to be installed!

By cantorsdust with credit to Karyme for the idea and r3dteam for technical help.

v1.1.2
Caught mistake in one of my file paths, corrected.  Thank you Eagle1337.

v1.1.1
adds catch for not finding the INI at all, so that won't crash and I won't have to answer a thousand questions

v1.1
fixes time setting bug on sleep, adds config INI for whether mines and caves should be counted as "inside"