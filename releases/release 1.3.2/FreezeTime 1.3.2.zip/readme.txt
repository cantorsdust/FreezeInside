Freezes the game using the SMAPI Trainer Mod command "world_settime" when inside.  Unfreezes when outside.

Place dll in %appdata%\Stardew Valley\Mods.  REQUIRES BOTH SMAPI AND TrainerMod.dll to be installed!

By cantorsdust with credit to Karyme for the idea and r3dteam for technical help.

v1.3.2
Fixed bug in resetting time after day change.

v1.3.1
Fixed logic error preventing frozen time inside mines and caves.

v1.3
Updated for SMAPI 0.37

v1.2.1
Fixes bug where time is being set to XX:90 when jumping back from XX:00.

v1.2
Will now create an INI if you don't have one.

v1.1.2
Caught mistake in one of my file paths, corrected.  Thank you Eagle1337.

v1.1.1
adds catch for not finding the INI at all, so that won't crash and I won't have to answer a thousand questions

v1.1
fixes time setting bug on sleep, adds config INI for whether mines and caves should be counted as "inside"