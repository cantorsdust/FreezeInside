Freezes the game using the SMAPI Trainer Mod command "world_freezetime 1" when inside.  Unfreezes when outside.

Place dll in %appdata%\Stardew Valley\Mods.  REQUIRES BOTH SMAPI AND TrainerMod.dll to be installed!

By cantorsdust with credit to Karyme for the idea and r3dteam for technical help.